#ifndef BACKTRACKING_H
#define BACKTRACKING_H



class BackTracking
{
public:
    BackTracking();
    int N=10;
    void printSolution(int sol[10][10]);
    bool solveMaze(int maze[10][10]);
    bool solveMazeUtil(int maze[10][10], int x, int y, int sol[10][10]);
    bool isSafe(int maze[10][10], int x, int y);
};

#endif // BACKTRACKING_H

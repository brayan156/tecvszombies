var indexSectionsWithContent =
{
  0: "abcdefghilmnprstuvxyz~",
  1: "bcegmprtyz",
  2: "u",
  3: "abcegmprtyz",
  4: "abcdefgimprstuyz~",
  5: "abcdefghlmnprstuvxyz",
  6: "p",
  7: "cr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Macros"
};


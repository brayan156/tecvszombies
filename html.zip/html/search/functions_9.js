var searchData=
[
  ['par',['Par',['../classPar.html#a9cd402219274024fb2421212af6144e7',1,'Par']]],
  ['pasar_5fgeneracion',['pasar_generacion',['../classGame.html#a1379dbb58016a9f79dd373f4925a93d7',1,'Game']]],
  ['poner_5fa_5fcaminar',['poner_a_caminar',['../classEnemy.html#a3518b1d76ae7a1e8a3c9591bd0b767ad',1,'Enemy']]]
];

var searchData=
[
  ['velocidad',['velocidad',['../classZombie.html#a28c51d6364729eca5a713bf1f59c6a0c',1,'Zombie']]],
  ['vida',['vida',['../classZombie.html#ab68230b18d70cadf72bc8884d9c26ace',1,'Zombie']]],
  ['vida_5fincial',['vida_incial',['../classZombie.html#a110c8e54988d826e3190e80f65319b00',1,'Zombie']]]
];

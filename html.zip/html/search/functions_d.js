var searchData=
[
  ['updatematrizback',['updateMatrizBack',['../classGame.html#a66880e17692521ef97f94ba8fc1bae12',1,'Game']]]
];

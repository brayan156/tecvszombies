var searchData=
[
  ['scene',['scene',['../classGame.html#a8119e3b9a632906c6808fa294b46a92a',1,'Game']]],
  ['siguiente_5fpunto',['siguiente_punto',['../classEnemy.html#abc0270b3de989fd2bd754e169c4de46a',1,'Enemy']]],
  ['solucion',['solucion',['../classBackTracking.html#ab52de5cc6318fedbcbba6af8967a74d9',1,'BackTracking']]],
  ['spawntimer',['spawnTimer',['../classEstadisticasview.html#acea42bff1e4313fac342971e12057bca',1,'Estadisticasview::spawnTimer()'],['../classGame.html#abc879849d50e2c5d5abd7987b531dabc',1,'Game::spawnTimer()']]],
  ['stats',['stats',['../classZombie.html#ae1a14725a34e97ea0605a96bfe302d30',1,'Zombie']]]
];

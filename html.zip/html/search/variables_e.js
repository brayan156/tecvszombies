var searchData=
[
  ['tiempo_5fspawn',['tiempo_spawn',['../classGame.html#a6bab6673c493e480a4d31895c4579fd3',1,'Game']]],
  ['timer',['timer',['../classEnemy.html#a70012228edd80bdbf5d71374f0b7ef9e',1,'Enemy']]],
  ['tipo',['tipo',['../classTower.html#a671a7dea0f393d3ed32ba6a8622bb384',1,'Tower::tipo()'],['../classZombie.html#abeeab49f14624308fe9513e89f7c4979',1,'Zombie::tipo()']]],
  ['track',['track',['../classGame.html#af67c968b5d0f2c9d5da11ba296270c9a',1,'Game']]]
];

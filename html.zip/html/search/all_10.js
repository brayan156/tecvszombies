var searchData=
[
  ['ui',['Ui',['../namespaceUi.html',1,'Ui'],['../classMainWindow.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()']]],
  ['updatematrizback',['updateMatrizBack',['../classGame.html#a66880e17692521ef97f94ba8fc1bae12',1,'Game']]]
];

var searchData=
[
  ['res_5farquero',['Res_arquero',['../classZombie.html#af672fd082b2fb385e7817629fdb25135',1,'Zombie']]],
  ['res_5fartillero',['Res_artillero',['../classZombie.html#a6703c8d8176ca81d21d3449784865c67',1,'Zombie']]],
  ['res_5ffuego',['Res_fuego',['../classZombie.html#a0f281b35137cd706d0f10606f0510896',1,'Zombie']]],
  ['res_5fmago',['Res_mago',['../classZombie.html#a18704815dbac127b9c9b7bb1611c9586',1,'Zombie']]],
  ['ruta',['ruta',['../classEnemy.html#a6669e20c0447ab7bfaa19242eb831bcc',1,'Enemy']]]
];

var searchData=
[
  ['n',['N',['../classBackTracking.html#a8681df3122e9c9d183998c7fc95bacfc',1,'BackTracking']]],
  ['nivel',['nivel',['../classTower.html#ac212c9573d5799f20fa991752004c0f0',1,'Tower']]],
  ['num_5fgeneracion',['num_generacion',['../classGenetico.html#aaf361cee07a233f07791dcbb05c36302',1,'Genetico']]],
  ['numero_5fenemigos',['numero_enemigos',['../classGame.html#a544c5962ac8721696ed1ed2436338672',1,'Game']]]
];

#include "par.h"

Par::Par()
{

}

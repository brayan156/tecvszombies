#ifndef PAR_H
#define PAR_H


class Par
{
public:
    Par();
    int y; int x;
};

#endif // PAR_H

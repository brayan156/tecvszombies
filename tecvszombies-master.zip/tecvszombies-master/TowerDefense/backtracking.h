#ifndef BACKTRACKING_H
#define BACKTRACKING_H
#define N 10


class BackTracking
{
public:
    BackTracking();
    void printSolution(int sol[N][N]);
    bool solveMaze(int maze[N][N]);
    bool solveMazeUtil(int maze[N][N], int x, int y, int sol[N][N]);
    bool isSafe(int maze[N][N], int x, int y);
};

#endif // BACKTRACKING_H

#include "zombie.h"
#include <iostream>
#include <QDebug>
Zombie::Zombie()
{

}

void Zombie::crear_zombie_ramdon()
{
    int tipo=rand()%4;

    if (tipo==0){
        crear_Orco();
    }
    else if (tipo==1) {
       crear_Elfo();
    }
    else if (tipo==2) {
        crear_Harpia();
    }
    else {
       crear_Mercenario();
    }
}



void Zombie::crear_Orco()
{

    stats[this->tipo]=1;
    stats[this->velocidad]=3;
    stats[this->vida]= rand()%30+50;

    for (int i=3; i<7; ++i) {
        float r = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
        float d = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);

        if(r<0.1){
            r += 0.2;
        }

        if (i==this->Res_arquero){
            stats[i]=r;
        }else if (i==this->Res_mago){
            stats[i]=d+1;
        }else if (i==this->Res_artillero){
            stats[i]=d+1;
        }else {
            stats[i]=d+1;
        }

    }

}

void Zombie::crear_Elfo()
{
    stats[this->tipo]=2;
    stats[this->velocidad]=5;
    stats[this->vida]= rand()%30+50;

    for (int i=3; i<7; ++i) {
        float r = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
        float d = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);

        if(r<0.1){
            r += 0.2;
        }

        if (i==this->Res_arquero){
            stats[i]=r;
        }else if (i==this->Res_mago){
            stats[i]=r;
        }else if (i==this->Res_artillero){
            stats[i]=d+1;
        }else {
            stats[i]=d+1;
        }

    }
}

void Zombie::crear_Harpia()
{
    stats[this->tipo]=3;
    stats[this->velocidad]=5;
    stats[this->vida]= rand()%30+50;

    for (int i=3; i<7;i++){
        stats[i]= 1;

    }
}

void Zombie::crear_Mercenario()
{
    stats[this->tipo]=4;
    stats[this->velocidad]=8;
    stats[this->vida]= rand()%30+50;

    for (int i=3; i<7; ++i) {
        float r = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
        float d = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);

        if(r<0.1){
            r += 0.2;
        }

        if (i==this->Res_arquero){
            stats[i]=r;
        }else if (i==this->Res_mago){
            stats[i]=r;
        }else if (i==this->Res_artillero){
            stats[i]=r;
        }else {
            stats[i]=d+1;
        }

    }

}
